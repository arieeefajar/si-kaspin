<?php $__env->startSection('title', 'Etalase'); ?>
<?php $__env->startSection('titleHeader', 'Etalase'); ?>
<?php $__env->startSection('menu', 'Menu'); ?>
<?php $__env->startSection('subMenu', 'Etalase'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row h-100">
        <div class="col-xl-12">
            <div class="card card-height-100">
                <!-- card body -->
                <div class="card-body">
                    <div class="align-items-center d-flex-column">
                        <form action="<?php echo e(route('etalase.search')); ?>" method="GET" class="app-search d-flex">
                            <div class="position-relative">
                                <input type="text" name="cari" id="cari" class="form-control rounded-pill"
                                    placeholder="Search...">
                                <span class="mdi mdi-magnify search-widget-icon"></span>
                            </div>
                        </form>
                        <div class="row">
                            <div class="col">
                                <div class="row">
                                    <?php $__currentLoopData = $etalase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-3">
                                            <div class="card" id="cardItem" data-bs-toggle="modal"
                                                data-bs-target="#addItemModal">
                                                <div class="row g-0">
                                                    <div class="col-md-12">
                                                        <img class="rounded-start img-fluid h-100 object-cover"
                                                            src="<?php echo e(asset('/storage/gambarProduk/' . $item->gambar)); ?>"
                                                            alt="Card image">
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="card-header">
                                                            <h5 class="card-title mb-0"><?php echo e($item->nama_produk); ?></h5>
                                                        </div>
                                                        <div class="card-body">
                                                            <p class="card-text mb-2">Rp.
                                                                <?php echo e(number_format($item->harga_satuan, 0, ',', '.')); ?></p>
                                                            <p class="card-text"><small
                                                                    class="text-muted"><?php echo e($item->nama_kategori); ?> | Stok:
                                                                    <?php echo e($item->stock); ?></small></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div><!-- end card -->
                                        </div><!-- end col -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $etalase->withQueryString()->links('pagination::bootstrap-5'); ?>

                                </div><!-- end row -->
                            </div><!-- end col -->
                        </div><!-- end row -->
                    </div>
                </div>
                <!-- end card body -->
            </div><!-- end card -->
        </div><!-- end col -->
    </div> <!-- end row-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\si-kaspin\resources\views/etalase.blade.php ENDPATH**/ ?>