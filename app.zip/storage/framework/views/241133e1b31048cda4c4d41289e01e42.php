
<?php $__env->startSection('title', 'Operator'); ?>
<?php $__env->startSection('titleHeader', 'Operator'); ?>
<?php $__env->startSection('menu', 'Operator'); ?>
<?php $__env->startSection('subMenu', 'User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-8">
            <div class="card">
                <div class="card-body">
                    <div id="customerList">
                        <div class="row g-4 mb-3">
                            <div class="col-sm-auto">
                                <div class="d-flex justify-content-sm-end">
                                    <div class="search-box ms-2">
                                        <input type="text" class="form-control search" placeholder="Search...">
                                        <i class="ri-search-line search-icon"></i>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="table mt-3 mb-1">
                            <table class="table align-middle table-nowrap" id="customerTable">
                                <tbody class="list form-check-all">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="card" id="cardItem" data-bs-toggle="modal"
                                                        data-bs-target="#addItemModal">
                                                        <div class="row g-0">
                                                            <div class="col-md-4">
                                                                <img class="rounded-start img-fluid h-100 object-cover"
                                                                    src="<?php echo e(asset('admin_assets/assets/images/small/img-12.jpg')); ?>"
                                                                    alt="Card image">
                                                            </div>
                                                            <div class="col-md-8">
                                                                <div class="card-header">
                                                                    <h5 class="card-title mb-0">Batako Kotak
                                                                        Biasa</h5>
                                                                </div>
                                                                <div class="card-body">
                                                                    <p class="card-text mb-2">Rp. 10.000</p>
                                                                    <p class="card-text"><small class="text-muted">Bata |
                                                                            Stok:
                                                                            40</small></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- end card -->
                                                </div><!-- end col -->
                                                <div class="col-md-6">
                                                    <div class="card">
                                                        <div class="row g-0">
                                                            <div class="col-md-4">
                                                                <img class="rounded-start img-fluid h-100 object-cover"
                                                                    src="<?php echo e(asset('admin_assets/assets/images/small/img-12.jpg')); ?>"
                                                                    alt="Card image">
                                                            </div>
                                                            <div class="col-md-8">
                                                                <div class="card-header">
                                                                    <h5 class="card-title mb-0">Batako Kotak Biasa</h5>
                                                                </div>
                                                                <div class="card-body">
                                                                    <p class="card-text mb-2">Rp. 10.000</p>
                                                                    <p class="card-text"><small class="text-muted">Bata |
                                                                            Stok:
                                                                            40</small></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- end card -->
                                                </div><!-- end col -->
                                                <div class="col-md-6">
                                                    <div class="card">
                                                        <div class="row g-0">
                                                            <div class="col-md-4">
                                                                <img class="rounded-start img-fluid h-100 object-cover"
                                                                    src="<?php echo e(asset('admin_assets/assets/images/small/img-12.jpg')); ?>"
                                                                    alt="Card image">
                                                            </div>
                                                            <div class="col-md-8">
                                                                <div class="card-header">
                                                                    <h5 class="card-title mb-0">Batako Kotak Biasa</h5>
                                                                </div>
                                                                <div class="card-body">
                                                                    <p class="card-text mb-2">Rp. 10.000</p>
                                                                    <p class="card-text"><small class="text-muted">Bata |
                                                                            Stok:
                                                                            40</small></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- end card -->
                                                </div><!-- end col -->
                                            </div><!-- end row -->
                                        </div><!-- end col -->
                                    </div><!-- end row -->
                                </tbody>
                            </table>

                            
                            <div class="noresult" style="display: none">
                                <div class="text-center">
                                    <lord-icon src="https://cdn.lordicon.com/msoeawqm.json" trigger="loop"
                                        colors="primary:#121331,secondary:#08a88a" style="width:75px;height:75px">
                                    </lord-icon>
                                    <h5 class="mt-2">Maaf! Hasil Pencarian Tidak Ditemukan</h5>
                                </div>
                            </div>
                        </div>

                        
                        <div class="d-flex justify-content-end">
                            <div class="pagination-wrap hstack gap-2">
                                <a class="page-item pagination-prev disabled" href="#">
                                    < </a>
                                        <ul class="pagination listjs-pagination mb-0"></ul>
                                        <a class="page-item pagination-next" href="#">
                                            >
                                        </a>
                            </div>
                        </div>
                    </div>
                </div><!-- end card -->
            </div>
            <!-- end col -->
        </div>
        <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('otherJs'); ?>
    <!-- prismjs plugin -->
    <script src="<?php echo e(asset('admin_assets/assets/libs/prismjs/prism.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/assets/libs/list.js/list.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/assets/libs/list.pagination.js/list.pagination.min.js')); ?>"></script>

    <!-- listjs init -->
    <script src="<?php echo e(asset('admin_assets/assets/js/pages/listjs.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\si-kaspin\resources\views/penjualan1.blade.php ENDPATH**/ ?>