<?php $__env->startSection('title', 'Dashboard | Admin'); ?>
<?php $__env->startSection('titleHeader', 'Dashboard'); ?>
<?php $__env->startSection('menu', 'Menu'); ?>
<?php $__env->startSection('subMenu', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xxl-15">
            <div class="d-flex flex-column h-100">
                <div class="row">
                    <!-- Jumlah Penjualan -->
                    <div class="col-md-6">
                        <div class="card card-animate">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h5 class="card-title">Jumlah Penjualan </h5>
                                        <h6 class="card-subtitle mb-2 text-muted">Total penjualan produk saat ini</h6>
                                        <p class="card-text">
                                        <h3><?php echo e($jumlahPenjualan); ?></h3>
                                        </p>
                                    </div>
                                    <div>
                                        <div class="avatar-sm flex-shrink-0">
                                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                                                <i data-feather="pie-chart" class="text-info"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- end card body -->
                        </div> <!-- end card-->
                    </div> <!-- end col-->

                    <!-- Jumlah Pembelian -->
                    <div class="col-md-6">
                        <div class="card card-animate">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h5 class="card-title">Jumlah Pembelian </h5>
                                        <h6 class="card-subtitle mb-2 text-muted">Total pembelian produk saat ini</h6>
                                        <p class="card-text">
                                        <h3><?php echo e($jumlahPembelian); ?></h3>
                                        </p>
                                    </div>
                                    <div>
                                        <div class="avatar-sm flex-shrink-0">
                                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                                                <i data-feather="bar-chart-2" class="text-info"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- end card body -->
                        </div> <!-- end card-->
                    </div> <!-- end col-->

                    <!-- Total Pemasukan -->
                    <div class="col-md-3">
                        <div class="card card-animate">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <p class="fw-medium text-muted mb-0">Total Pemasukan</p>
                                        <p class="mb-0 text-muted">
                                        <h2>Rp. <?php echo e(number_format($totalPenjualan, 0, ',', '.')); ?></h2>
                                        </p>
                                    </div>
                                    <div>
                                        <div class="avatar-sm flex-shrink-0">
                                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                                                <i data-feather="dollar-sign" class="text-info"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- end card body -->
                        </div> <!-- end card-->
                    </div> <!-- end col-->

                    <!-- Total Pengeluaran -->
                    <div class="col-md-3">
                        <div class="card card-animate">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <p class="fw-medium text-muted mb-0">Total Pengeluaran</p>
                                        <p class="mb-0 text-muted">
                                        <h2>Rp. <?php echo e(number_format($totalPembelian, 0, ',', '.')); ?></h2>
                                        </p>

                                    </div>
                                    <div>
                                        <div class="avatar-sm flex-shrink-0">
                                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                                                <i data-feather="dollar-sign" class="text-info"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- end card body -->
                        </div> <!-- end card-->
                    </div> <!-- end col-->

                    <!-- Total Kerugian -->
                    <div class="col-md-3">
                        <div class="card card-animate">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <p class="fw-medium text-muted mb-0">Total Kerugian</p>
                                        <p class="mb-0 text-muted">
                                            <?php if($totalKerugian > 0): ?>
                                                <h2>Rp. <?php echo e(number_format($totalKerugian, 0, ',', '.')); ?></h2>
                                            <?php else: ?>
                                                <h2>Rp. 0</h2>
                                            <?php endif; ?>
                                            
                                        </p>
                                    </div>
                                    <div>
                                        <div class="avatar-sm flex-shrink-0">
                                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                                                <i data-feather="trending-down" class="text-info"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- end card body -->
                        </div> <!-- end card-->
                    </div> <!-- end col-->

                    <!-- Total Laba -->
                    <div class="col-md-3">
                        <div class="card card-animate">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <p class="fw-medium text-muted mb-0">Total Laba</p>
                                        <p class="mb-0 text-muted">
                                            <?php if($totalLaba > 0): ?>
                                                <h2>Rp. <?php echo e(number_format($totalLaba, 0, ',', '.')); ?></h2>
                                            <?php else: ?>
                                                <h2>Rp. 0</h2>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <div>
                                        <div class="avatar-sm flex-shrink-0">
                                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                                                <i data-feather="trending-up" class="text-info"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- end card body -->
                        </div> <!-- end card-->
                    </div> <!-- end col-->
                </div> <!-- end row-->

                <div class="row">
                    <!-- Total Penjualan per Bulan -->
                    <div class="col-xl-4">
                        <div class="card card-height-90">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">Total Penjualan per Bulan</h4>
                                <div class="flex-shrink-0">
                                    <form id="salesMonthForm" method="GET" action="<?php echo e(route('dashboard')); ?>">
                                        <select name="bulan_penjualan" id="salesMonthSelector" class="form-select form-select-sm"
                                            onchange="document.getElementById('salesMonthForm').submit();">
                                            <?php for($i = 1; $i <= 12; $i++): ?>
                                                <option value="<?php echo e($i); ?>" <?php echo e($i == $bulanPenjualan ? 'selected' : ''); ?>>
                                                    <?php echo e(DateTime::createFromFormat('!m', $i)->format('F')); ?>

                                                </option>
                                            <?php endfor; ?>
                                        </select>
                                        <select name="tahun_penjualan" id="salesYearSelector" class="form-select form-select-sm"
                                            onchange="document.getElementById('salesMonthForm').submit();">
                                            <?php for($i = 2020; $i <= date('Y'); $i++): ?>
                                                <option value="<?php echo e($i); ?>" <?php echo e($i == $tahunPenjualan ? 'selected' : ''); ?>>
                                                    <?php echo e($i); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </form>
                                </div>
                            </div>
                            <div class="card-body">
                                <canvas id="salesChart" width="100%" height="120"></canvas>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                    </div><!-- end col -->

                    <!-- Total Pembelian per Bulan -->
        <div class="col-xl-4">
            <div class="card card-height-90">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Total Pembelian per Bulan</h4>
                    <div class="flex-shrink-0">
                        <form id="purchasesMonthForm" method="GET" action="<?php echo e(route('dashboard')); ?>">
                            <select name="bulan_pembelian" id="purchasesMonthSelector" class="form-select form-select-sm"
                                onchange="document.getElementById('purchasesMonthForm').submit();">
                                <?php for($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php echo e($i == $bulanPembelian ? 'selected' : ''); ?>>
                                        <?php echo e(DateTime::createFromFormat('!m', $i)->format('F')); ?>

                                    </option>
                                <?php endfor; ?>
                            </select>
                            <select name="tahun_pembelian" id="purchasesYearSelector" class="form-select form-select-sm"
                                onchange="document.getElementById('purchasesMonthForm').submit();">
                                <?php for($i = 2020; $i <= date('Y'); $i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php echo e($i == $tahunPembelian ? 'selected' : ''); ?>>
                                        <?php echo e($i); ?></option>
                                <?php endfor; ?>
                            </select>
                        </form>
                    </div>
                </div>
                <div class="card-body">
                    <canvas id="purchasesChart" width="100%" height="120"></canvas>
                </div><!-- end card body -->
            </div><!-- end card -->
        </div><!-- end col -->

                    <!-- Kategori Produk -->
                    <div class="col-xl-4">
                        <div class="card card-height-90">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">Kategori Produk</h4>
                            </div>
                            <div class="card-body">
                                <canvas id="productCategoryChart" width="100%" height="120"></canvas>
                            </div><!-- end card body -->
                        </div><!-- end card -->
                    </div><!-- end col -->
                </div><!-- end row -->
            </div>
        </div> <!-- end col-->
  
        <!-- Best Seller -->
        <div class="col-xl-4 col-md-6">
            <div class="card card-height-100">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Best Seller</h4>
                </div><!-- end card header -->
                <div class="card-body">
                    <div class="table-responsive table-card">
                        <table class="table align-middle table-borderless table-centered table-nowrap mb-0">
                            <thead class="text-muted table-light">
                                <tr>
                                    <th scope="col" style="width: 62px;">Nama Produk</th>

                                    <th scope="col" style="width: 62px;">Total Penjualan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $produkBestSeller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($produk['nama_produk']); ?></td>
                                        <td><?php echo e($produk['jumlah']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody><!-- end tbody -->
                        </table><!-- end table -->
                    </div><!-- end table-responsive -->
                </div><!-- end card body -->
            </div><!-- end card -->
        </div><!-- end col -->
    </div><!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('otherJs'); ?>
    <!-- apexcharts -->
    <script src="<?php echo e(asset('admin_assets/assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>

    <!-- Vector map-->
    <script src="<?php echo e(asset('admin_assets/assets/libs/jsvectormap/js/jsvectormap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/assets/libs/jsvectormap/maps/world-merc.js')); ?>"></script>

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Dashboard init -->
    <script>
        // penjualan
        document.addEventListener('DOMContentLoaded', function() {
            var ctx = document.getElementById('salesChart').getContext('2d');
            var salesChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($namaProduk, 15, 512) ?>,
                    datasets: [{
                        label: 'Total Produk Terjual',
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1,
                        data: <?php echo json_encode($jumlahProduk, 15, 512) ?>
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });

        // pembelian
        document.addEventListener('DOMContentLoaded', function() {
            var ctx = document.getElementById('purchasesChart').getContext('2d');
            var purchasesChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($nmProduk, 15, 512) ?>,
                    datasets: [{
                        label: 'Total Produk Dibeli',
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1,
                        data: <?php echo json_encode($jmlProduk, 15, 512) ?>
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });
    </script>

    <!-- Inisialisasi Chart -->
    <script>
        var ctx = document.getElementById('productCategoryChart').getContext('2d');
        var productCategoryChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($kategoriProdukLabel); ?>,
                datasets: [{
                    label: 'Produk per Kategori',
                    data: <?php echo json_encode($kategoriProdukData); ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.6)',
                        'rgba(54, 162, 235, 0.6)',
                        'rgba(255, 206, 86, 0.6)',
                        'rgba(75, 192, 192, 0.6)',
                        'rgba(153, 102, 255, 0.6)',
                        'rgba(255, 159, 64, 0.6)'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\si-kaspin\resources\views/dashboard.blade.php ENDPATH**/ ?>