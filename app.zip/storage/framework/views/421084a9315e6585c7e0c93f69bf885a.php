<div class="container-fluid">
    <div class="row">
        <div class="col-sm-6">
            <script>
                document.write(new Date().getFullYear())
            </script> © JTI Polije.
        </div>
        <div class="col-sm-6">
            <div class="text-sm-end d-none d-sm-block">
                Design & Develop by YTeam
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\si-kaspin\resources\views/layout/footer.blade.php ENDPATH**/ ?>